/*
  # Create chat messages table

  1. New Tables
    - `chat_messages`
      - `id` (uuid, primary key) - Unique identifier for each message
      - `content` (text) - The message content
      - `role` (text) - Either 'user' or 'assistant' to identify message sender
      - `created_at` (timestamptz) - Timestamp when message was created
      - `session_id` (text) - Optional session identifier to group conversations
  
  2. Security
    - Enable RLS on `chat_messages` table
    - Add policy for anyone to insert messages (public chatbot)
    - Add policy for anyone to read messages (public chatbot)
    
  3. Notes
    - This is a public chatbot accessible without authentication
    - Messages are stored for chat history and continuity
*/

CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content text NOT NULL,
  role text NOT NULL CHECK (role IN ('user', 'assistant')),
  session_id text DEFAULT 'default',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert messages"
  ON chat_messages
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can view messages"
  ON chat_messages
  FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE INDEX IF NOT EXISTS idx_chat_messages_session ON chat_messages(session_id, created_at);