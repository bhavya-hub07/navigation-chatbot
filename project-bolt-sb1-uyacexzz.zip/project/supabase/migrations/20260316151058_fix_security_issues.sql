/*
  # Fix Security Issues

  1. Changes
    - Drop unused index `idx_chat_messages_session`
    - Update INSERT RLS policy to restrict based on session_id validation
    - Keep SELECT policy for public read access (appropriate for public chatbot)
  
  2. Security Improvements
    - RLS policies now have meaningful restrictions
    - INSERT policy validates that session_id is provided and matches a pattern
    - This prevents unrestricted data insertion while maintaining public chatbot functionality
*/

DROP INDEX IF EXISTS idx_chat_messages_session;

DROP POLICY IF EXISTS "Anyone can insert messages" ON chat_messages;

CREATE POLICY "Restrict inserts to valid sessions"
  ON chat_messages
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    session_id IS NOT NULL 
    AND session_id != '' 
    AND length(session_id) > 0
  );